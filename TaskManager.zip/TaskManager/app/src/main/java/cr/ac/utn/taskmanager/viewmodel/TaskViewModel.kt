package cr.ac.utn.taskmanager.viewmodel

import androidx.lifecycle.ViewModel
import cr.ac.utn.taskmanager.domain.model.Task
import cr.ac.utn.taskmanager.domain.repository.ITaskRepository
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking

class TaskViewModel(
    private val repository: ITaskRepository
): ViewModel() {
    fun getTasks(): List<Task>{
        return runBlocking {
            try {
                repository.getTasks().first()
            } catch (e: Exception) {
                emptyList()
            }
        }
    }

    fun getTaskById(id: String): Task?{
        return runBlocking {
            repository.getById(id)
        }
    }

    fun saveTask(task: Task){
        runBlocking {
            repository.addTask(task)
        }
    }

    fun updateTask(task: Task){
        runBlocking {
            repository.updateTask(task)
        }
    }

    fun removeTask(id: String){
        runBlocking {
            repository.deleteTask(id)
        }
    }
}
